// bcm2835_add.h
// Extended C and C++ support for Broadcom BCM 2835 as used in Raspberry Pi
// http://elinux.org/RPi_Low-level_peripherals
// http://www.raspberrypi.org/wp-content/uploads/2012/02/BCM2835-ARM-Peripherals.pdf
//
// Author: Matevz Bosnak (matevz.bosnak@gmail.com)
// Copyright (C) 2012 Matevz Bosnak

// Defines for BCM2835
#ifndef BCM2835_ADD_H
#define BCM2835_ADD_H

#include "bcm2835.h"

#ifdef __cplusplus
extern "C" {
#endif


    extern int bcm2835_add_init(int i2cBus);
    extern int bcm2835_add_close();

    
    /// Transfers any number of bytes to and from the currently selected SPI slave using FIFO buffer.
    /// Asserts the currently selected CS pins (as previously set by bcm2835_spi_chipSelect) 
    /// during the transfer.
    /// Clocks the len 8 bit bytes out on MOSI, and simultaneously clocks in data from MISO. 
    /// The returned data from the slave replaces the transmitted data in the buffer.
    /// Uses polled transfer as per section 10.6.1 of teh BCM 2835 ARM Peripherls manual
    /// \param[in,out] buf Buffer of bytes to send. Received bytes will replace the contents
    /// \param[in] len Number of bytes int eh buffer, and the number of bytes to send/received
    /// \sa bcm2835_spi_transfer()
    extern void bcm2835_spi_transfernFIFO(char* buf, uint32_t len);


	extern void bcm2835_pwm_init(uint32_t config, uint16_t clockDiv);
	extern void bcm2835_pwm0_setRange(uint32_t range);
	extern void bcm2835_pwm0_setData(uint32_t data);
	extern uint32_t bcm2835_pwm_getStatus();
	
  #define I2C_SLAVE	                            0x0703	  ///< Change slave address
  extern uint32_t bcm2835_i2c_setAddr(uint8_t addr);
  extern uint32_t bcm2835_i2c_write(uint8_t * data, uint8_t data_num);
  extern uint32_t bcm2835_i2c_read(uint8_t * data, uint8_t data_num);

	
    /// @} 

#ifdef __cplusplus
}
#endif

#endif // BCM2835_H