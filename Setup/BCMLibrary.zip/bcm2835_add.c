// bcm2835_add.c
// Extended C and C++ support for Broadcom BCM 2835 as used in Raspberry Pi
// http://elinux.org/RPi_Low-level_peripherals
// http://www.raspberrypi.org/wp-content/uploads/2012/02/BCM2835-ARM-Peripherals.pdf
//
// Author: Matevz Bosnak (matevz.bosnak@gmail.com)
// Copyright (C) 2012 Matevz Bosnak

#include "bcm2835.h"
#include "bcm2835_add.h"
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>

// This define enables a little test program (by default a blinking output on pin RPI_GPIO_PIN_11)
// You can do some safe, non-destructive testing on any platform with:

// Locals to hold pointers to the hardware
static volatile int i2cFile = 0;

// Writes (and reads) an number of bytes to SPI
void bcm2835_spi_transfernFIFO(char* buf, uint32_t len)
{
    volatile uint32_t* paddr = bcm2835_spi0 + BCM2835_SPI0_CS/4;
    volatile uint32_t* fifo = bcm2835_spi0 + BCM2835_SPI0_FIFO/4;

    // This is Polled transfer as per section 10.6.1
    // BUG ALERT: what happens if we get interupted in this section, and someone else
    // accesses a different peripheral? 

    // Clear TX and RX fifos
    bcm2835_peri_write_nb(paddr, BCM2835_SPI0_CS_CLEAR);

    // Set TA = 1
    bcm2835_peri_set_bits(paddr, BCM2835_SPI0_CS_TA, BCM2835_SPI0_CS_TA);

    uint32_t i, j = 0;
    uint32_t cnt = 0;
	
	while(1)
	{
		// Maybe wait for TXD
		while (!(bcm2835_peri_read(paddr) & BCM2835_SPI0_CS_TXD))
			delayMicroseconds(10);
		
		// Write first 16 bytes immediately to FIFO
		for (i = 0; i < 16; i++)
		{
			// Write to FIFO, no barrier
			bcm2835_peri_write_nb(fifo, buf[cnt]);
			if (++cnt >= len) break;
		}

		// and read them back...

		// Wait for DONE to be set
		while (!(bcm2835_peri_read_nb(paddr) & BCM2835_SPI0_CS_DONE))
		delayMicroseconds(10);

		for (; j < cnt; j++)
		{
			// then read the data byte
			buf[j] = bcm2835_peri_read_nb(fifo);
		}	
		
		if (cnt >= len) break;	
	}
    
    // Set TA = 0, and also set the barrier
    bcm2835_peri_set_bits(paddr, 0, BCM2835_SPI0_CS_TA);
}




void bcm2835_pwm_init(uint32_t config, uint16_t clockDiv)
{
	volatile uint32_t* paddr = bcm2835_pwm + BCM2835_PWM_CONTROL;
	*paddr = config;
	
	// Setup clock source and divider
	paddr = bcm2835_clk + BCM2835_PWMCLK_DIV; 
	*paddr = 0x5A000000 | ((uint32_t)clockDiv << 12);
	
	paddr = bcm2835_clk + BCM2835_PWMCLK_CNTL;
	*paddr = 0x5A000011;
}

void bcm2835_pwm0_setRange(uint32_t range)
{
	volatile uint32_t* paddr = bcm2835_pwm + BCM2835_PWM0_RANGE;
	*paddr = range;
}

void bcm2835_pwm0_setData(uint32_t data)
{
	volatile uint32_t* paddr = bcm2835_pwm + BCM2835_PWM0_DATA;
	*paddr = data;
}

uint32_t bcm2835_pwm_getStatus()
{
	volatile uint32_t* paddr = bcm2835_pwm + BCM2835_PWM_STATUS;
	return *paddr;
}

// I2C commands
uint32_t bcm2835_i2c_setAddr(uint8_t addr)
{
  if (ioctl(i2cFile, I2C_SLAVE, addr) < 0) 
  {
    return 0;
  }
  return 1;
}

uint32_t bcm2835_i2c_write(uint8_t * data, uint8_t data_num)
{
  int result = write(i2cFile, data, data_num);
  
  if (result <= 0) return 0; 
  else return result;
}

uint32_t bcm2835_i2c_read(uint8_t * data, uint8_t data_num)
{
  int result = read(i2cFile, data, data_num);
  
  if (result <= 0) return 0; 
  else return result;
}


// Initialise this library
int bcm2835_add_init(int i2cBus)
{
  if (bcm2835_init())
  {  
    // I2C - use system support for i2c
    if (i2cBus == 0)
    {
       i2cFile = open("/dev/i2c-0", O_RDWR); // Open I2C interface for read/write
    } else
    {
       i2cFile = open("/dev/i2c-1", O_RDWR); // Open I2C interface for read/write
    }
    if (i2cFile < 0) 
    {
      fprintf(stderr, "bcm2835_init: open failed (i2c): %s\n", strerror(errno)) ;
      return 0;
    }

    // Success
    return 1;
  } else 
    return 0;
}

int bcm2835_add_close()
{
  close(i2cFile);
  
  bcm2835_close();
}